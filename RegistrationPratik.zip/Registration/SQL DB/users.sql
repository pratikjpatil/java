create database users;
use users;
create table registration(name varchar(20),address varchar(50),gender char(10),age int, mobile varchar(20), email varchar(30), username varchar(20), password varchar(20));
desc registration;